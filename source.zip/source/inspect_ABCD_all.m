function inspect_ABCD_all(PECAP_Data, param, delay)

% inspect_ABCD_all(PECAP_Data, param, delay)
%   cycles through all recorded ABCD traces in a PECAP data collection
%   matrix to allow the user to view whether there are issues with
%   non-matching recording electrodes where the stimulus artefacts don't
%   match between traces that have copied A and D frames from other ECAP
%   recordings for redundancy & time-savings reasons.
%
%   Inputs:
%       - PECAP_Data:   Data structure output with ECAP recorded data.
%                       Takes outputs from run_PECAP(), run_BlurCAP(), and
%                       run_pTPECAP().
%       - param:        parameter structure with ECAP recording information
%       - delay:        (Optional): the number of seconds to delay prior to
%                       moving onto plotting and printing information for
%                       the next Neural Response Telemetry (NRT) trace.
%   Outputs:
%       n/a
%
% Required Software:
%   plot_ABCD_frames_AB(signal_all, param)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, August 2021                                           %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set delay to 2 if none is specified
if nargin == 2
    delay = 2;
end

% cycle through
for ii = 1:length(PECAP_Data)
    % plot all the frames
    plot_ABCD_frames_AB(PECAP_Data(ii).frames,param);
    % print out details of the recorded trace
    fprintf('\nNRT = %d / %d',ii,length(PECAP_Data));
    fprintf('\n\tProbe: %d',PECAP_Data(ii).Probe);
    fprintf('\n\tMasker: %d',PECAP_Data(ii).Masker);
    fprintf('\n\tRecord: %d',PECAP_Data(ii).Recording);
    % indicate if A & D frames were copied from another recorded trace
    if isfield(PECAP_Data(ii).frames,'ADframesTrace')
        fprintf('\n\tA&D Frames Copied from Trace %d', ...
            PECAP_Data(ii).frames.ADframesTrace);
        fprintf('\n\t\tCopied Trace RecElec: %d', ...
            PECAP_Data(PECAP_Data(ii).frames.ADframesTrace).Recording)
        % print out an error in case the recording electrodes don't match
        if PECAP_Data(ii).Recording ~= ...
                PECAP_Data(PECAP_Data(ii).frames.ADframesTrace).Recording
            fprintf('\n\t\tRecording Electrodes Don''t match!');
        end
    end
    % delay so each graph and print-outs can be inspected
    fprintf('\n');
    pause(delay)
end