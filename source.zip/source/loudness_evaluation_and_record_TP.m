function [level_recorded, recording_EL, signal_recorded, ECAP_Struct, responses] = ...
    loudness_evaluation_and_record_TP(handle_BEDCS, signal_struct, param)

% Loudness-Scaling GUI for partial Tripolar ECAP stimulation

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Developed by Francois Guerit                                            %
% Ammended by Charlotte Garcia, July 2021                                 %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Variables
global level step resp range recorded_signals list_levels_played list_recording_EL...
    stimObj h_graph_ecap ECAP_Data alpha
step = 6;
resp = [];
range = 0;
recorded_signals = [];
ECAP_Data = struct();
list_levels_played = [];
list_recording_EL = [];
stimObj = signal_struct;
alpha = stimObj.alpha;

list_loudness_text = {...
    'Just Noticeable ';...
    'Very Soft ';...
    'Soft ';...
    'Comfortable but too Soft ';...
    'Comfortable but Soft ';...
    'Most Comfortable ';...
    'Loud but Comfortable ';...
    'Loud ';...
    'Upper Loudness Limit ';...
    'Too Loud '};

list_parameters = struct(signal_struct);
list_parameters = rmfield(list_parameters,'level'); % Remove the level property
rangeBool = isfield(list_parameters,'range');
if rangeBool
    range = signal_struct.range;    
    list_parameters = rmfield(list_parameters,'range'); % Remove the range property
end
two_levels_bool = 0;
if numel(signal_struct.level) == 2
    two_levels_bool = 1;
    level = [0 0];    
else
    level = 0;
end

%% Figure Layout

width_window = 200;
height_window = 40;
title = 'Loudness Evaluation';

% Get maximum value of the screen
set(0, 'Units', 'characters');
screen = get(0, 'ScreenSize');
% Define the position of the window, based on the value of the screen
pos = struct('width', width_window, 'height', height_window);
pos.left = floor(screen(3) / 2) - floor(pos.width / 2);
pos.bottom = floor(screen(4) / 2) - floor(pos.height / 2);

% Build the figure
h_figure = figure('Units', 'characters', ...
    'Position', [pos.left pos.bottom pos.width pos.height], ...
    'MenuBar', 'none', ...
    'NumberTitle', 'off', ...
    'Name', title, ...
    'HandleVisibility', 'callback');

%% Figure with results

h_axes_results = axes('Parent',h_figure,...
    'Position',[0.78 0.65 0.20 0.30],...
    'Visible','on');
h_plot_results = plot(h_axes_results,NaN(1,10),1:10,'ob','markerfacecolor','b');
xlabel(h_axes_results,'Level')
ylabel(h_axes_results,'Ranking')
ylim(h_axes_results,[0 11])

%% External figure with eCAP

handle_fig_ecap = figure;
h_axes_ecap = axes('Parent', handle_fig_ecap);
h_graph_ecap = plot(h_axes_ecap, [0 20], [0 0], '-', 'LineWidth', 2);
xlabel(h_axes_ecap,'Time (ms)')
ylabel(h_axes_ecap,'Amp (mV)')
ylim(h_axes_ecap, 'auto')
xlim(h_axes_ecap, 'auto')
h_axes_ecap.Title.String = 'The eCAP monitor';

%% Level info
h_level_text = uicontrol(h_figure, ...
    'Style', 'text', ...
    'Tag', 'level_text', ...
    'Units', 'characters', ...
    'Position', [2 5*pos.height/6 (floor(pos.width /4)- 4) 2], ...
    'Enable', 'on', ...
    'Fontsize', 14, ...
    'HorizontalAlignment', 'right',...
    'String', 'Level (Device Units): ');

if two_levels_bool
    h_masker_text = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', 'masker_text', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+pos.width/4) 11*pos.height/12 (floor(pos.width /8)- 4) 2], ...
        'Enable', 'on', ...
        'Fontsize', 12, ...
        'String', 'Masker');
    
    h_probe_text = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', 'probe_text', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+3*pos.width/8) 11*pos.height/12 (floor(pos.width /8)- 4) 2], ...
        'Enable', 'on', ...
        'Fontsize', 12, ...
        'String', 'Probe');
    
    h_level_value = uicontrol(h_figure, ...
        'Style', 'edit', ...
        'Tag', 'level_value', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+pos.width/4) 5*pos.height/6 (floor(pos.width /8)- 4) 2], ...
        'Enable', 'off', ...
        'Fontsize', 14, ...
        'String', '0',...
        'Callback', {@level_value_callback,h_figure});
    
    h_level2_value = uicontrol(h_figure, ...
        'Style', 'edit', ...
        'Tag', 'level2_value', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+3*pos.width/8) 5*pos.height/6 (floor(pos.width /8)- 4) 2], ...
        'Enable', 'off', ...
        'Fontsize', 14, ...
        'String', '0',...
        'Callback', {@level2_value_callback,h_figure});
    
    h_level_value_db = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', 'level_value_db', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+pos.width/4) 9*pos.height/12 (floor(pos.width /8)- 4) 2], ...
        'Enable', 'on', ...
        'Fontsize', 10, ...
        'FontAngle','italic',...
        'String', '-inf dB re 1 uA');
    
    h_level2_value_db = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', 'level2_value_db', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+3*pos.width/8) 9*pos.height/12 (floor(pos.width /8)- 4) 2], ...
        'Enable', 'on', ...
        'Fontsize', 10, ...
        'FontAngle','italic',...
        'String', '-inf dB re 1 uA');
else
    h_level_value = uicontrol(h_figure, ...
        'Style', 'edit', ...
        'Tag', 'level_value', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+pos.width/4) 5*pos.height/6 (floor(pos.width /4)- 4) 2], ...
        'Enable', 'off', ...
        'Fontsize', 14, ...
        'String', '0',...
        'Callback', {@level_value_callback,h_figure});
    
    h_level_value_db = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', 'level_value_db', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+pos.width/4) 9*pos.height/12 (floor(pos.width /4)- 4) 2], ...
        'Enable', 'on', ...
        'Fontsize', 12, ...
        'FontAngle','italic',...
        'String', '-inf dB re 1 uA');
end

%% Alpha info
h_alpha_text = uicontrol(h_figure, ...
    'Style', 'text', ...
    'Tag', 'alpha_text', ...
    'Units', 'characters', ...
    'Position', [2 8*pos.height/16 (floor(pos.width /4)- 4) 2], ...
    'Enable', 'on', ...
    'Fontsize', 14, ...
    'HorizontalAlignment', 'right',...
    'String', 'alpha (0=MP 1=fullTP): ');

h_alpha_value = uicontrol(h_figure, ...
    'Style', 'edit', ...
    'Tag', 'alpha_edit', ...
    'Units', 'characters', ...
    'BackgroundColor', 'w', ...
    'Position', [(2+pos.width/4) 8*pos.height/16 (floor(pos.width /4)- 4) 2], ...
    'Enable', 'off', ...
    'Fontsize', 14, ...
    'String', num2str(alpha),...
    'Callback', {@alpha_value_callback,h_figure});

%% Step size info
h_step_text = uicontrol(h_figure, ...
    'Style', 'text', ...
    'Tag', 'step_text', ...
    'Units', 'characters', ...
    'Position', [2 7*pos.height/16 (floor(pos.width /4)- 4) 2], ...
    'Enable', 'on', ...
    'Fontsize', 14, ...
    'HorizontalAlignment', 'right',...
    'String', 'Step size (Device Units): ');

h_step_value = uicontrol(h_figure, ...
    'Style', 'edit', ...
    'Tag', 'step_edit', ...
    'Units', 'characters', ...
    'BackgroundColor', 'w', ...
    'Position', [(2+pos.width/4) 7*pos.height/16 (floor(pos.width /4)- 4) 2], ...
    'Enable', 'off', ...
    'Fontsize', 14, ...
    'String', num2str(step),...
    'Callback', {@step_value_callback,h_figure});

%% Range (if existing)
if rangeBool
    h_range_text = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', 'range_text', ...
        'Units', 'characters', ...
        'Position', [2 5*pos.height/16 (floor(pos.width /4)- 4) 2], ...
        'Enable', 'on', ...
        'Fontsize', 14, ...
        'HorizontalAlignment', 'right',...
        'String', 'Range of levels: ');
    
    h_range_value = uicontrol(h_figure, ...
        'Style', 'popup', ...
        'Tag', 'range_edit', ...
        'Units', 'characters', ...
        'BackgroundColor', 'w', ...
        'Position', [(2+pos.width/4) 5*pos.height/16 (floor(pos.width /4)- 4) 2], ...
        'Enable', 'off', ...
        'Fontsize', 14, ...
        'String', {'0','1','2','3'},...
        'Value', range + 1,...
        'Callback', {@range_value_callback,h_figure});
end

%% Parameters

if isfield(param,'blur_factor')
    if isfield(param,'start_alpha')
        h_title_parameters = uicontrol(h_figure, ...
            'Style', 'text', ...
            'Tag', 'title_parameters', ...
            'Units', 'characters', ...
            'Position', [(2+pos.width/2) (pos.height/2 - 3) (pos.width/2 - 4) 1.5], ...
            'Enable', 'on', ...
            'Fontsize', 12, ...
            'String', 'Starting Parameters (pTP)');
    else
        h_title_parameters = uicontrol(h_figure, ...
            'Style', 'text', ...
            'Tag', 'title_parameters', ...
            'Units', 'characters', ...
            'Position', [(2+pos.width/2) (pos.height/2 - 3) (pos.width/2 - 4) 1.5], ...
            'Enable', 'on', ...
            'Fontsize', 12, ...
            'String', ['Starting Parameters (Blur Factor: ' ...
            num2str(param.blur_factor) ')']);
    end
else
    if isfield(param,'start_alpha')
        h_title_parameters = uicontrol(h_figure, ...
            'Style', 'text', ...
            'Tag', 'title_parameters', ...
            'Units', 'characters', ...
            'Position', [(2+pos.width/2) (pos.height/2 - 3) (pos.width/2 - 4) 1.5], ...
            'Enable', 'on', ...
            'Fontsize', 12, ...
            'String', 'Starting Parameters (pTP)');
    else
        h_title_parameters = uicontrol(h_figure, ...
            'Style', 'text', ...
            'Tag', 'title_parameters', ...
            'Units', 'characters', ...
            'Position', [(2+pos.width/2) (pos.height/2 - 3) (pos.width/2 - 4) 1.5], ...
            'Enable', 'on', ...
            'Fontsize', 12, ...
            'String', 'Starting Parameters');
    end
end

h_parameters_text = ones(1,16);
h_parameters_value = ones(1,16);

for idx = 1:8
    h_parameters_text(idx) = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', ['parameters_text_' num2str(idx)], ...
        'Units', 'characters', ...
        'Position', [(2+pos.width/2) (pos.height/2 - (3+2*idx)) (pos.width/8 - 4) 1.5], ...
        'Enable', 'off', ...
        'HorizontalAlignment', 'right',...
        'String', ['Parameter ' num2str(idx)]);
    
    h_parameters_value(idx) = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', ['parameters_value_' num2str(idx)], ...
        'Units', 'characters', ...
        'Position', [(5*pos.width/8) (pos.height/2 - (3+2*idx)) (pos.width/8 - 4) 1.5], ...
        'Enable', 'off', ...
        'HorizontalAlignment', 'left',...
        'String', ['Value ' num2str(idx)]);
end

for idx = 9:16
    h_parameters_text(idx) = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', ['parameters_text_' num2str(idx)], ...
        'Units', 'characters', ...
        'Position', [(2+3*pos.width/4) (pos.height/2 - (3+2*(idx-8))) (pos.width/8 - 4) 1.5], ...
        'Enable', 'off', ...
        'HorizontalAlignment', 'right',...
        'String', ['Parameter ' num2str(idx)]);
    
    h_parameters_value(idx) = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', ['parameters_value_' num2str(idx)], ...
        'Units', 'characters', ...
        'Position', [(7*pos.width/8) (pos.height/2 - (3+2*(idx-8))) (pos.width/8 - 4) 1.5], ...
        'Enable', 'off', ...
        'HorizontalAlignment', 'left',...
        'String', ['Value ' num2str(idx)]);
end

%% Loudness buttons

h_loudness_push = ones(1,10);
h_loudness_text = ones(1,10);

for idx = 1:10
    h_loudness_text(idx) = uicontrol(h_figure, ...
        'Style', 'text', ...
        'Tag', ['loudness_text_' num2str(idx)], ...
        'Units', 'characters', ...
        'Position', [(4+pos.width/2) (pos.height/2 + 2*(idx-1)) (pos.width/8 +2 ) 1.5], ...
        'Enable', 'off', ...
        'HorizontalAlignment', 'right',...
        'String', list_loudness_text{idx});
    
    h_loudness_push(idx) = uicontrol(h_figure, ...
        'Style', 'push', ...
        'Tag', ['loudness_push_' num2str(idx)], ...
        'Units', 'characters', ...
        'Position', [(11*pos.width/16 - 2) (pos.height/2 + 2*(idx-1)) (pos.width/16 - 2) 1.5], ...
        'Enable', 'off', ...
        'String', num2str(idx), ...
        'Callback', {@push_callback_loudness,h_level_value,idx,h_plot_results});
    
    
end

%% Controls

%Add a pushbutton to go down in level
h_push_down = uicontrol(h_figure, ...
    'Style', 'pushbutton', ...
    'Tag', 'push_down', ...
    'Units', 'characters', ...
    'Position', [2 5*pos.height/8 (floor(pos.width /6)- 4) 4], ...
    'Enable', 'off', ...
    'Fontsize', 14, ...
    'String', 'Down',...
    'Callback', {@push_down_callback,h_figure, h_level_value});

%Add a pushbutton to play
h_push_play = uicontrol(h_figure, ...
    'Style', 'pushbutton', ...
    'Tag', 'push_play', ...
    'Units', 'characters', ...
    'Position', [(2 + floor(pos.width /6)) 5*pos.height/8 (floor(pos.width /6)- 4) 4], ...
    'Enable', 'off', ...
    'Fontsize', 14, ...
    'String', 'Play',...
    'Callback', {@push_play_callback,h_figure,handle_BEDCS,param});

%Add a pushbutton to go upin level
h_push_up = uicontrol(h_figure, ...
    'Style', 'pushbutton', ...
    'Tag', 'push_up', ...
    'Units', 'characters', ...
    'Position', [(2 + floor(pos.width /3)) 5*pos.height/8 (floor(pos.width /6)- 4) 4], ...
    'Enable', 'off', ...
    'Fontsize', 14, ...
    'String', 'Up',...
    'Callback', {@push_up_callback,h_figure,h_level_value});

%Add a pushbutton to clear loudness levels
h_push_clear = uicontrol(h_figure, ...
    'Style', 'pushbutton', ...
    'Tag', 'push_clear', ...
    'Units', 'characters', ...
    'Position', [(13*pos.width/16 - 1) 8*pos.height/16 (floor(pos.width /6)- 4) 2], ...
    'Enable', 'off', ...
    'Fontsize', 12, ...
    'String', 'Clear Last',...
    'Callback', {@push_clear_callback,h_plot_results});

%Add a pushbutton to exit
h_push_done = uicontrol(h_figure, ...
    'Style', 'pushbutton', ...
    'Tag', 'push_done', ...
    'Units', 'characters', ...
    'Position', [(2 + floor(pos.width /6)) 1*pos.height/6 (floor(pos.width /6)- 4) 4], ...
    'Enable', 'off', ...
    'Fontsize', 14, ...
    'String', 'Done',...
    'Callback', {@push_done_callback,h_figure,param});


%% Activate buttons

set(h_loudness_push, 'Enable', 'On')
set(h_loudness_text, 'Enable', 'On')
set(h_push_clear, 'Enable', 'On')
set(h_push_down, 'Enable', 'On')
set(h_push_play, 'Enable', 'On')
set(h_push_up, 'Enable', 'On')
set(h_push_done, 'Enable', 'Off')
set(h_level_value, 'Enable', 'On')
set(h_step_value, 'Enable', 'On')
set(h_alpha_value, 'Enable', 'On')

if rangeBool
    set(h_range_value, 'Enable', 'On')
end

if two_levels_bool
    set(h_level2_value, 'Enable', 'On')
end

%% Set background colors

set([h_level_text, h_level_value_db, h_loudness_text, h_masker_text, ...
    h_probe_text, h_parameters_text, h_parameters_value,...
    h_step_text, h_alpha_text, h_title_parameters, h_loudness_push],...
    'backgroundcolor',get(h_figure,'color'))

if rangeBool
    set(h_range_text,'backgroundcolor',get(h_figure,'color'))
end

if two_levels_bool
    set(h_level2_value_db, 'backgroundcolor',get(h_figure,'color'))
end

%% Update the parameters


names = fieldnames(list_parameters);
nParameters = length(names);
for idx = 1:min(nParameters,16)
    set(h_parameters_text(idx),'String',[names(idx) ' '],...
        'Enable','on')
    fieldValue = getfield(list_parameters,names{idx});
    if ~isstr(fieldValue)
        fieldValue = num2str(fieldValue);
    end
    set(h_parameters_value(idx),'String',fieldValue,...
        'Enable','on')
end

if nParameters < 16
    set(h_parameters_text(nParameters+1:16),'Visible','off')
    set(h_parameters_value(nParameters+1:16),'Visible','off')
end

%% set the callback for pressing a key
set(h_figure,'KeyPressFcn', {@key_pressed_fcn,h_level_value,h_plot_results})
set(findobj(h_figure, 'type', 'uicontrol', 'style', 'pushbutton'),'KeyPressFcn', {@key_pressed_fcn,h_level_value,h_plot_results})

%% Wait for the figure to be closed

uiwait(h_figure)

%% Resume
level_recorded = list_levels_played;
responses = resp;
signal_recorded = recorded_signals;
ECAP_Struct = ECAP_Data;
recording_EL = list_recording_EL;

if ishandle(h_figure)
    close(h_figure)
end

if ishandle(handle_fig_ecap)
    close(handle_fig_ecap)
end

end

function push_down_callback(obj,eventdata,h_figure,h_level_value)
global level step range stimObj

if length(stimObj.level) == 2
    two_levels_bool = 1;
    h_level2_value = findobj(h_figure,'Tag','level2_value');    
else
    two_levels_bool = 0;
end

level = level - step;
if two_levels_bool
    set(h_level_value, 'String', num2str(level(1)))
    set(h_level2_value, 'String', num2str(level(2)))
else
    set(h_level_value, 'String', num2str(level))
end

% Make the sure the push button is not highlighted
set(findobj('type', 'uicontrol'),'Enable','off')
drawnow
set(findobj('type', 'uicontrol'),'Enable','on')


stimObj.level = level;
if two_levels_bool
    stimObj.Imasker = level(1);
    stimObj.Iprobe = level(2);
else
    stimObj.Imasker = level(1);
    stimObj.Iprobe = level(1);
end

if isfield(struct(stimObj),'range')
    stimObj.range = range;
end

h_level_value_db = findobj(h_figure,'Tag','level_value_db');
value_db = 20*log10(stimObj.level);

if two_levels_bool
    h_level2_value_db = findobj(h_figure,'Tag','level2_value_db');    
    set(h_level_value_db, 'String', [num2str(round(value_db(1)*10)/10) ' dB re 1uA'])    
    set(h_level2_value_db, 'String', [num2str(round(value_db(2)*10)/10) ' dB re 1uA'])        
else
    set(h_level_value_db, 'String', [num2str(round(value_db(1)*10)/10) ' dB re 1uA'])
end
end

function push_play_callback(obj,eventdata,h_figure,h,param)
global level range recorded_signals list_levels_played list_recording_EL stimObj...
    h_graph_ecap ECAP_Data resp 

stimObj.level = level;

if isfield(struct(stimObj),'range')
    stimObj.range = range;
end

% Flash the button
originalColor = get(obj, 'backgroundcolor');
set(obj,'backgroundcolor','r')
pause(0.001) % Make sure the background has time to change color

if ishandle(h)
    % Update the stimulus properties
    fields = fieldnames(stimObj);
    for i = 1:length(fields)
        if ~strcmp(fields{i}, 'level')
            h.Let_ControlVarVal(fields{i},...
                stimObj.(fields{i}))
        end
    end
    
    % Play and get eCAP
    % fprintf('\nPlaying Stimulus at CL %d and CL %d\n',level(1),level(2));
    [signal_all, time_vector_ms] = run_BEDCS_and_get_ECAP(h,param);
    signal_that_level = signal_all.ECAP;
else
    pause(1);
    signal_that_level = rand(1, 10);
    time_vector_ms = 1:10;
end

recorded_signals = [recorded_signals; signal_that_level];
ECAP_Data(size(recorded_signals,1)).Probe = stimObj.ELprobe;
ECAP_Data(size(recorded_signals,1)).Probe_lvl = level(2);
ECAP_Data(size(recorded_signals,1)).Masker = stimObj.ELmasker;
ECAP_Data(size(recorded_signals,1)).Masker_lvl = level(1);
ECAP_Data(size(recorded_signals,1)).Recording = stimObj.ELrec;
ECAP_Data(size(recorded_signals,1)).PDus = stimObj.Tp;
ECAP_Data(size(recorded_signals,1)).MPIus = stimObj.Tdel;
ECAP_Data(size(recorded_signals,1)).ECAP = signal_all.ECAP;
ECAP_Data(size(recorded_signals,1)).frames = signal_all;
ECAP_Data(size(recorded_signals,1)).alpha = stimObj.alpha;
list_levels_played = [list_levels_played; level];
list_recording_EL = [list_recording_EL; stimObj.ELrec];

% Stop flashing
set(obj,'backgroundcolor',originalColor)

% Update eCAP data plot
[a, details] = ecap_amplitude(signal_that_level,time_vector_ms,param);
set(h_graph_ecap,'XData',time_vector_ms,'YData',signal_that_level);

% Make the sure the push button is not highlighted
set(findobj('type', 'uicontrol'),'Enable','off')
drawnow
set(findobj('type', 'uicontrol'),'Enable','on')

end

function push_up_callback(obj,eventdata,h_figure,h_level_value)
global level step range stimObj

if length(stimObj.level) == 2
    two_levels_bool = 1;
    h_level2_value = findobj(h_figure,'Tag','level2_value');    
else
    two_levels_bool = 0;
end

level = level + step;
if two_levels_bool
    set(h_level_value, 'String', num2str(level(1)))
    set(h_level2_value, 'String', num2str(level(2)))
else
    set(h_level_value, 'String', num2str(level))
end

% Make the sure the push button is not highlighted
set(findobj('type', 'uicontrol'),'Enable','off')
drawnow
set(findobj('type', 'uicontrol'),'Enable','on')

stimObj.level = level;
if two_levels_bool
    stimObj.Imasker = level(1);
    stimObj.Iprobe = level(2);
else
    stimObj.Imasker = level(1);
    stimObj.Iprobe = level(1);
end

if isfield(struct(stimObj),'range')
    stimObj.range = range;
end

h_level_value_db = findobj(h_figure,'Tag','level_value_db');
value_db = 20*log10(stimObj.level);

if two_levels_bool
    h_level2_value_db = findobj(h_figure,'Tag','level2_value_db');    
    set(h_level_value_db, 'String', [num2str(round(value_db(1)*10)/10) ' dB re 1uA'])    
    set(h_level2_value_db, 'String', [num2str(round(value_db(2)*10)/10) ' dB re 1uA'])        
else
    set(h_level_value_db, 'String', [num2str(round(value_db(1)*10)/10) ' dB re 1uA'])
end

end

function push_done_callback(obj,eventdata,h_figure,param)
% include global values to determine whether to deactivate Done button
global ECAP_Data

% collect already scaled loudness responses
if isfield(ECAP_Data,'LoudnessLevel')
    resp_levels = [ECAP_Data.LoudnessLevel];
else
    resp_levels = 0;
end

% collect the required loudness scaled levels
req_levels = param.loudness_options;

% initiate the boolean vector for determining if the loudness scaling
% requirements have been met
level_recorded = zeros(size(req_levels));

% determine if each of the required loudness levels have been recorded
for ii = 1:length(req_levels)
    level_recorded(ii) = nnz(resp_levels - req_levels(ii)) ~= ...
        length(resp_levels);
end

% if we have collected the required loudness level rankings
if min(level_recorded) == 1
    % This will run the last lines of the main function (after uiwait)
    uiresume(h_figure) 
else
    % if we have not collected the required loudness level rankings, the
    % GUI will not close and a warning to collect all required rankings
    % will be printed in the command window.
    fprintf('\nMust enter loudness scaling for levels ')
    for ii = 1:length(param.loudness_options)
        if ii == length(param.loudness_options)
            fprintf(['and ' num2str(param.loudness_options(ii))]);
        else
            fprintf([num2str(param.loudness_options(ii)) ', ']);
        end
    end
    fprintf('.\n Otherwise the ''Done'' button will remain inactive.\n')
end

end

function push_clear_callback(obj,eventdata,h_plot_results)
% clear all loudness values
global resp ECAP_Data recorded_signals

resp(end,:) = [];
set(h_plot_results,'xdata',resp(:,2),'ydata',resp(:,1))

% Make the sure the push button is not highlighted
set(findobj('type', 'uicontrol'),'Enable','off')
drawnow
set(findobj('type', 'uicontrol'),'Enable','on')

% clear loudness level response for most recent recording
if size(recorded_signals,1) ~= 0
    ECAP_Data(size(recorded_signals,1)).LoudnessLevel = [];
end

end

function push_callback_loudness(obj,eventdata,level_handle,idx_loudness,h_plot_results)
% Assigns the main level value to a particular loudness step (idx_loudness)
global resp level ECAP_Data recorded_signals

% Set the value in the loudness vector
resp = [resp; idx_loudness, level];

% set the value in the ECAP_Struct object
if size(recorded_signals,1) ~= 0
    ECAP_Data(size(recorded_signals,1)).LoudnessLevel = ...
        resp(size(resp,1),1);
end

set(h_plot_results,'XData',resp(:,2),'YData',resp(:,1))

% Make the sure the push button is not highlighted
set(findobj('type', 'uicontrol'),'Enable','off')
drawnow
set(findobj('type', 'uicontrol'),'Enable','on')

end


function step_value_callback(obj, eventdata, h_figure)
global step

% Make sure the step value is updated
drawnow

value_step = str2num(get(obj, 'String'));
if isempty(value_step)
    commandwindow
    warning('The step size must be numerical')
    set(obj,'String',step)
    drawnow
else
    step = value_step;
end

end

function alpha_value_callback(obj, eventdata, h_figure)
global alpha stimObj

% Make sure the alpha value is updated
drawnow

value_alpha = str2num(get(obj, 'String'));
if isempty(value_alpha)
    commandwindow
    warning('The alpha size must be numerical')
    set(obj,'String',alpha)
    drawnow
elseif value_alpha < 0 || value_alpha > 1
    warning('The alpha value must between 0 and 1')
    set(obj,'String',alpha)
    drawnow
else
    alpha = value_alpha;
end

stimObj.alpha = alpha;

end

function range_value_callback(obj, eventdata, h_figure)
global range level stimObj

% Make sure the step value is updated
drawnow

range = get(obj, 'Value') - 1;

stimObj.level = level;
if two_levels_bool
    stimObj.Imasker = level(1);
    stimObj.Iprobe = level(2);
else
    stimObj.Imasker = level(1);
    stimObj.Iprobe = level(1);
end

if isfield(struct(stimObj),'range')
    stimObj.range = range;
end

h_level_value_db = findobj(h_figure,'Tag','level_value_db');
value_db = 20*log10(stimObj.level);

if length(level) == 2
    h_level2_value_db = findobj(h_figure,'Tag','level2_value_db');    
    set(h_level_value_db, 'String', [num2str(round(value_db(1)*10)/10) ' dB re 1uA'])    
    set(h_level2_value_db, 'String', [num2str(round(value_db(2)*10)/10) ' dB re 1uA'])        
else
    set(h_level_value_db, 'String', [num2str(round(value_db(1)*10)/10) ' dB re 1uA'])
end

end


function level_value_callback(obj, eventdata, h_figure)
global level range stimObj

% Make sure the level value is updated
drawnow

value_level = str2num(get(obj, 'String'));
if isempty(value_level)
    commandwindow
    warning('The level must be numerical')
    set(obj,'String',level(1))
    drawnow    
else
    level(1) = value_level;
end

stimObj.level(1) = level(1);
stimObj.Imasker = level(1);

if isfield(struct(stimObj),'range')
    stimObj.range = range;
end

h_level_value_db = findobj(h_figure,'Tag','level_value_db');
value_db = 20*log10(stimObj.level);

set(h_level_value_db, 'String', [num2str(round(value_db(1)*10)/10) ' dB re 1uA'])

end

function level2_value_callback(obj, eventdata, h_figure)
global level range stimObj

% Make sure the level value is updated
drawnow

value_level = str2num(get(obj, 'String'));
if isempty(value_level)
    commandwindow
    warning('The level must be numerical')
    set(obj,'String',level(2))
    drawnow    
else
    level(2) = value_level;
end

stimObj.level(2) = level(2);
stimObj.Iprobe = level(2);

if isfield(struct(stimObj),'range')
    stimObj.range = range;
end

h_level_value_db = findobj(h_figure,'Tag','level2_value_db');
value_db = 20*log10(stimObj.level);

set(h_level_value_db, 'String', [num2str(round(value_db(2)*10)/10) ' dB re 1uA'])

end

function key_pressed_fcn(obj,eventDat,level_handle,h_plot_results)
% function when pressing a key

switch eventDat.Key
    case '0'
        idx_loudness = 0;    
    case '1'
        idx_loudness = 1;
    case '2'
        idx_loudness = 2;
    case '3'
        idx_loudness = 3;
    case '4'
        idx_loudness = 4;
    case '5'
        idx_loudness = 5;
    case '6'
        idx_loudness = 6;
    case '7'
        idx_loudness = 7;
    case '8'
        idx_loudness = 8;
    case '9'
        idx_loudness = 9;
    case 'x'
        idx_loudness = 10;
    otherwise
        idx_loudness = [];
end

if ~isempty(idx_loudness)
    % Call the corresponding button callback
    obj = findobj('tag',['loudness_push_' num2str(idx_loudness)]);
    push_callback_loudness(obj,eventDat,level_handle,idx_loudness,h_plot_results)
end

end