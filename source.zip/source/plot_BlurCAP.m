function BlurCAP_Data = plot_BlurCAP(PECAP_Data, BlurCAP_Data, param)

% BlurCAP_Data = plot_BlurCAP(PECAP_Data, BlurCAP_Data, param)
%   plots BlurCAP M matrix from Advanced Bionics data, as well as returning
%   the passed structure of PECAP data with the ECAP amplitudes included.
%   Takes the outputs of run_PECAP() run_BlurCAP() as inputs
%
%   Inputs:
%       - PECAP_Data:   structure containing monopolar PECAP data that is
%                       the output of run_PECAP()
%       - BlurCAP_Data: structure containing blurred PECA data that is the
%                       output of run_BlurCAP()
%       - param:        structure containing recording parameters that is
%                       required for visualisation within the plot
%   Outputs:
%       - BlurCAP_Data: updated BlurCAP_Data structure with the ECAP
%                       amplitudes included in the raw recorded data
%
% Required Software: 
%   PECAP_Data = run_PECAP(param);
%   PECAP_Data = run_BlurCAP(param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 28 May 2021                                           %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Calculate ECAP Amplitudes (in uV) and store in M
% find min and max electrodes
elecs = [min([PECAP_Data.Probe]) max([PECAP_Data.Probe])];

% initiate M matrix with zeros
M = zeros(elecs(2) - elecs(1) + 1);

% go through PECAP data structure, calculate ECAP amplitudes, store in M
for ii = 1:length(PECAP_Data)
    [a, details] = ecap_amplitude(PECAP_Data(ii).ECAP, ...
        PECAP_Data(ii).frames.time, param);
    PECAP_Data(ii).Amp_uV = a*1000;
    PECAP_Data(ii).N1P2 = details;
    M(PECAP_Data(ii).Probe - elecs(1) + 1, ...
        PECAP_Data(ii).Masker - elecs(1) + 1) = a*1000;
end

% go through BlurCAP data structure & replace blurred ECAPs
for ii = 1:length(BlurCAP_Data)
    for jj = 1:length(BlurCAP_Data(ii).Blurred_ECAPs)
        [a, details] = ecap_amplitude(BlurCAP_Data(ii).Blurred_ECAPs(jj).ECAP, ...
            BlurCAP_Data(ii).Blurred_ECAPs(jj).frames.time, param);
        BlurCAP_Data(ii).Blurred_ECAPs(jj).Amp_uV = a*1000;
        BlurCAP_Data(ii).Blurred_ECAPs(jj).details = details;
        M(BlurCAP_Data(ii).Blurred_ECAPs(jj).Probe - elecs(1) + 1, ...
            BlurCAP_Data(ii).Blurred_ECAPs(jj).Masker - elecs(1) + 1) = a*1000;
    end
    BlurCAP_Data(ii).M = M;
end

%% Plot
for ii = 1:length(BlurCAP_Data)
    figure;
    imagesc(BlurCAP_Data(ii).M); xticks(1:length(M)); yticks(1:length(M));
    xticklabels(elecs(1):elecs(2)); yticklabels(elecs(1):elecs(2)); 
    xlabel('Masker Electrode'); ylabel('Probe Electrode');
    title(['Mo for ' param.ID ', e',  ...
        num2str(BlurCAP_Data(ii).Blurred_Electrode), ...
        ', Blur Factor: ', num2str(BlurCAP_Data(ii).Blur_Factor)]);
    h = colorbar; h.Label.String = 'ECAP Amplitude (\muV)';
    
    % save figure
    datetimestr = datestr(datetime);
    savefig(['data/figs/Subj' param.ID '_cond' param.condition ...
        '_BlurCAP_e' num2str(BlurCAP_Data(ii).Blurred_Electrode) ...
        '_factor' num2str(BlurCAP_Data(ii).Blur_Factor) '_' date '_' ...
        datetimestr(13:14) '-' datetimestr(16:17) '-' ...
        datetimestr(19:20)]);
end