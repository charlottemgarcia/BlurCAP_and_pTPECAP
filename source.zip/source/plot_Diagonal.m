function ecap_amps = plot_Diagonal(Diagonal_ECAP_Data, param)

% ecap_amps = plot_Diagonal(Diagonal_ECAP_Data, param)
%   takes an input that is the output of run_diagonal_ecap and plots the
%   ECAP amplitudes along the electrode array, as well as all the waveforms
%   in a separate figure. Optionally requires the param struct to be passed
%   in order to determine the Masker-Probe Interval (MPI) for ECAP
%   amplitude calculation. If not passed, it's assumed that the MPI is
%   500us.
%
%   Inputs:
%       - Diagonal_ECAP_Data:   structure containing ECAP data that is the
%                               output of the run_diagonal_ecap() function
%       - param:                structure containing recording parameters 
%                               that is required for calculating ECAP
%                               amplitudes and inferring the MPI. If not
%                               provided, the MPI is assumed to be 500us
%   Outputs:
%       - ecap_amps:            vector of ECAP amplitudes along the length
%                               of the array that are plotted in the figure
%
% Required Software:
%   Diagonal_ECAP_Data = run_diagonal_ecap(param)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 28 May 2021                                           %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% plot ECAP waveforms
% set to fill the whole screen so the waveforms are visible
figure('units','normalized','outerposition',[0 0 1 1]); 
ecap_amps = zeros(1,length(Diagonal_ECAP_Data));

for ii = 1:16
    subplot(4,4,ii); hold on;
    title(['Electrode ' num2str(ii)]);
    if any(param.electrodes == ii)
        % if the electrode was included in data collection
        % find index for data in data structure
        idx = find(param.electrodes == ii);
        % plot waveform
        plot(Diagonal_ECAP_Data(idx).frames.time, ...
            Diagonal_ECAP_Data(idx).ECAP);
        % calculate the ECAP amplitude
        [a, details] = ecap_amplitude(Diagonal_ECAP_Data(idx).ECAP, ...
            Diagonal_ECAP_Data(idx).frames.time,param);
        % store amplitude in ecap amplitude vector
        ecap_amps(idx) = a;
        % plot the N1 and P2
        r = scatter(details(:,1),details(:,2),'ro');
        legend(r,{['Amp = ' num2str(a*1000) ' \muV']},'location','best'); 
        legend boxoff
        xlim([-0.1 2.1]); xlabel('time (ms)'); xticks(0:0.5:2);
        yRange_ECAP = [min(Diagonal_ECAP_Data(idx).ECAP)-0.1 ...
            max(Diagonal_ECAP_Data(idx).ECAP)+0.1];
        ylim(yRange_ECAP); ylabel('Voltage (mV)');
    else
        % if the electrode was not included in the data collection
        xlim([0 1]); ylim([0 3]); yticks(-1:5:5); xticks(-1:3:2);
        text(0.2,2,'ECAP not')
        text(0.2,1,'recorded')
    end
end

% save figure
datetimestr = datestr(datetime);
savefig(['data/figs/Subj' param.ID '_cond' param.condition ...
    '_DiagonalWaveforms_MCL' num2str(param.MCL_loudnesslevel) '_' date ...
    '_' datetimestr(13:14) '-' datetimestr(16:17) '-' datetimestr(19:20)]);

%% plot ECAP diagonal
figure;

% plot ECAP amplitudes
plot(param.electrodes,ecap_amps,'k-o');
xlim([0.5 16.5]); xticks(1:16); xlabel('Stimulating Electrodes');
ylim([0 max(ecap_amps) + 0.1]); ylabel('ECAP Amplitude (mV)');
title('ECAP Amplitudes along the Diagonal'); hold on;

% get the noise level from the D frames & add to figure
stdev_vec = zeros(1,length(Diagonal_ECAP_Data));
for ii = 1:length(Diagonal_ECAP_Data)
    stdev_vec(ii) = std([Diagonal_ECAP_Data(ii).frames.D]);
end
noise_floor = 3*mean(stdev_vec);
red = area([0 17],[noise_floor noise_floor],'FaceColor','r', ...
    'FaceAlpha',0.3, 'EdgeAlpha',0.3);
legend(red,['3\sigma noise floor = ' num2str(noise_floor*1000) '\muV'], ...
    'location','best'); legend boxoff

% save figure
datetimestr = datestr(datetime);
savefig(['data/figs/Subj' param.ID '_cond' param.condition ...
    '_DiagonalAmplitudes_MCL' num2str(param.MCL_loudnesslevel) '_' date ...
    '_' datetimestr(13:14) '-' datetimestr(16:17) '-' datetimestr(19:20)]);