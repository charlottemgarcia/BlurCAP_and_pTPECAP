function PECAP_Data = plot_PECAP(PECAP_Data, param)

% PECAP_Data = plot_PECAP(PECAP_Data, param)
%   plots PECAP M matrix from Advanced Bionics data, as well as returning
%   the passed structure of PECAP data with the calculated ECAP amplitudes
%   included in addition to the raw waveform recordings
%
%   Inputs:
%       - PECAP_Data:   structure containing monopolar PECAP data that is
%                       the output of run_PECAP()
%       - param:        structure containing recording parameters that is
%                       required for visualisation within the plot
%   Outputs:
%       - PECAP_Data:   updated PECAP_Data structure with the ECAP
%                       amplitudes included in the raw recorded data
%
% Required Software:
%   PECAP_Data = run_PECAP(param);
%   [a, details, mask] = ecap_amplitude(v, t, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 28 May 2021                                           %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Calculate ECAP Amplitudes (in uV) and store in M
% find min and max electrodes
elecs = [min([PECAP_Data.Probe]) max([PECAP_Data.Probe])];

% initiate M matrix with zeros
M = zeros(elecs(2) - elecs(1) + 1);

% go through PECAP data structure, calculate ECAP amplitudes, store in M
for ii = 1:length(PECAP_Data)
    [a, details] = ecap_amplitude(PECAP_Data(ii).ECAP, ...
        PECAP_Data(ii).frames.time, param);
    PECAP_Data(ii).Amp_uV = a*1000;
    PECAP_Data(ii).N1P2 = details;
    M(PECAP_Data(ii).Probe - elecs(1) + 1, ...
        PECAP_Data(ii).Masker - elecs(1) + 1) = a*1000;
end

%% Plot
figure(7);
imagesc(M); xticks(1:length(M)); yticks(1:length(M));
xticklabels(elecs(1):elecs(2)); yticklabels(elecs(1):elecs(2)); 
xlabel('Masker Electrode'); ylabel('Probe Electrode');
title(['PECAP Matrix for ' param.ID]);
h = colorbar; h.Label.String = 'ECAP Amplitude (\muV)';

% save figure
datetimestr = datestr(datetime);
savefig(['data/figs/Subj' param.ID '_cond' param.condition ...
    '_PECAP_' date '_' datetimestr(13:14) '-' ...
    datetimestr(16:17) '-', datetimestr(19:20)]);