function pTPECAP_Data = plot_pTPECAP(PECAP_Data, pTPECAP_Data, param)

% pTPECAP_Data = plot_pTPECAP(PECAP_Data, pTPECAP_Data, param)
%   plots pTPECAP M matrix from Advanced Bionics data, as well as returning
%   the passed structure of pTPECAP data with the ECAP amplitudes included.
%   Takes the outpus of run_PECAP() and run_pTPECAP() as inputa
%
%   Inputs:
%       - PECAP_Data:   structure containing monopolar PECAP data that is
%                       the output of run_PECAP()
%       - pTPECAP_Data: structure containing partial tripolar PECAP data 
%                       that is the output of run_pTPECAP()
%       - param:        structure containing recording parameters that is
%                       required for visualisation within the plot
%   Outputs:
%       - pTPECAP_Data: updated pTPECAP_Data structure with the ECAP
%                       amplitudes included in the raw recorded data
%
% Required Software: 
%   PECAP_Data = run_PECAP(param);
%   PECAP_Data = run_pTPECAP(param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 07 July 2021                                          %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Calculate ECAP Amplitudes (in uV) and store in M
% find min and max electrodes
elecs = [min([PECAP_Data.Probe]) max([PECAP_Data.Probe])];

% initiate M matrix with zeros
M = zeros(elecs(2) - elecs(1) + 1);

% fill out M matrices
for ii = 1:length(pTPECAP_Data)
    % go through PECAP data structure, calculate ECAP amplitudes, store in M
    for kk = 1:length(PECAP_Data)
        [a, details] = ecap_amplitude(PECAP_Data(kk).ECAP, ...
            PECAP_Data(kk).frames.time, param);
        PECAP_Data(kk).Amp_uV = a*1000;
        PECAP_Data(kk).N1P2 = details;
        M(PECAP_Data(kk).Probe - elecs(1) + 1, ...
            PECAP_Data(kk).Masker - elecs(1) + 1) = a*1000;
    end
    % go through pTPECAP data structure & replace pTP ECAPs
    for jj = 1:length(pTPECAP_Data(ii).pTP_ECAPs)
        [a, details] = ecap_amplitude(pTPECAP_Data(ii).pTP_ECAPs(jj).ECAP, ...
            pTPECAP_Data(ii).pTP_ECAPs(jj).frames.time, param);
        pTPECAP_Data(ii).pTP_ECAPs(jj).Amp_uV = a*1000;
        pTPECAP_Data(ii).pTP_ECAPs(jj).details = details;
        M(pTPECAP_Data(ii).pTP_ECAPs(jj).Probe - elecs(1) + 1, ...
            pTPECAP_Data(ii).pTP_ECAPs(jj).Masker - elecs(1) + 1) = a*1000;
    end
    pTPECAP_Data(ii).M = M;
end

%% Plot
for ii = 1:length(pTPECAP_Data)
    figure;
    imagesc(pTPECAP_Data(ii).M); xticks(1:length(M)); yticks(1:length(M));
    xticklabels(elecs(1):elecs(2)); yticklabels(elecs(1):elecs(2)); 
    xlabel('Masker Electrode'); ylabel('Probe Electrode');
    title(['M_o for ' param.ID ', pTP elec: ' ...
        num2str(pTPECAP_Data(ii).Electrode) ', \alpha = ' ...
        num2str(pTPECAP_Data(ii).alpha)]);
    h = colorbar; h.Label.String = 'ECAP Amplitude (\muV)';
    
    % save figure
    datetimestr = datestr(datetime);
    savefig(['data/figs/Subj' param.ID '_cond' param.condition ...
        '_pTPECAP_e' num2str(pTPECAP_Data(ii).Electrode) '_alpha' ...
        num2str(pTPECAP_Data(ii).alpha*10) '_' date '_' ...
        datetimestr(13:14) '-' datetimestr(16:17) '-' ...
        datetimestr(19:20)]);
end