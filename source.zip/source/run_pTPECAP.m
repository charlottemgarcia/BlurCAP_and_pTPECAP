function PECAP_Data = run_pTPECAP(param)

% PECAP_Data = run_pTPECAP(param)
%   takes the loudness levels indicated in the param structure from the
%   fpartial tripolar loudness GUI and collects pTPECAP for the pTP
%   values indicated. Only does this for 1 electrode; must be run again if
%   more than one electrode is desired to be focused. This function only
%   collects 1 row and column of the PECAP matrix because those are the
%   only masker/prbe combinations affected by the focusing. That data is
%   integrated into the standard monopolar PECAP data in order to compare
%   to the full monopolar PECAP matrix
%
%   Inputs:
%       - param:    structure containing recording parameters required for
%                   recording Blurred ECAPs
%   Outputs:
%       - PECAP_Data:   structure containing recorded blurred ECAP data
%
% Required Software: 
%   signal_all = run_BEDCS_and_get_ECAP(h, param);
%   signal_all = run_BEDCS_and_get_BC(h, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 07 July 2021                                          %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% start timer
start = clock;

%% set diagonal parameters & initiate data structure
electrodes = param.electrodes;
MCL_levels = param.MCL_levels;
PECAP_Data = struct();
ii = 1; rec_move = 0;

%% update MCL levels for focused (pTP) electrode
MCL_levels(param.pTP_elec-min(electrodes)+1) = param.pTP_lvl;

%% Loop through different ECAP recordings
for pidx = 1:length(electrodes)
    % Set parameters for probe
    param.electrode_probe = electrodes(pidx);
    param.level_start_probe = MCL_levels(pidx);          
    
    for midx = 1:length(electrodes)
        % set parameters for masker
        param.electrode_masker = electrodes(midx);
        param.level_start_masker = MCL_levels(midx);  
        
        % limit to row/col of pTP electrode
        if param.electrode_masker == param.pTP_elec || ...
                param.electrode_probe == param.pTP_elec
        
            % set parameters for recording electrode
            if param.electrodes(pidx) + param.rel_rec_EL >= 1 && ...
                    electrodes(pidx) + param.rel_rec_EL <= 16
                % avoid recording on the masker electrode
                if electrodes(midx) == electrodes(pidx) + param.rel_rec_EL
                    param.rec_EL = electrodes(pidx) + param.rel_rec_EL + 1;     % may have to change + to -
                    rec_move = 1;
                else
                    param.rec_EL = electrodes(pidx) + param.rel_rec_EL;
                end
            else
                % avoid recording on the probe electrode
                if electrodes(midx) == electrodes(pidx) - param.rel_rec_EL
                    param.rec_EL = electrodes(pidx) - param.rel_rec_EL - 1;     % may have to change - to +
                    rec_move = 1;
                else
                    param.rec_EL = electrodes(pidx) - param.rel_rec_EL;
                end
            end  

            % create stimulas structure to pass to BEDCS
            stim_struct.ELrec = param.rec_EL;     
            stim_struct.Tp = param.phase_duration_us;
            stim_struct.Tdel = param.masker_probe_delay_us;
            stim_struct.level = [param.level_start_masker param.level_start_probe];
            stim_struct.Imasker = param.level_start_masker;
            stim_struct.Iprobe = param.level_start_probe;
            stim_struct.ELmasker = param.electrode_masker;
            stim_struct.ELprobe = param.electrode_probe;
            stim_struct.alpha = param.pTP_alpha;

            % if we are on the diagonal, then record ABCD frames w focusing
            % on both electrodes
            if param.electrodes(pidx) == param.electrodes(midx)
                param.exp_file = ...
                    sprintf('ForwardMaskingPTP_gain_%d_%dkHz_%d_repeats.bExp',...
                    param.gain, param.fs_kHz, param.sweeps); 
            % if we aren't on the diagonal but the probe is focused, then
            % record ABCD frames w probe focused
            elseif param.electrode_probe == param.pTP_elec
                param.exp_file = ...
                    sprintf('ForwardMaskingPTP_P_gain_%d_%dkHz_%d_repeats.bExp',...
                    param.gain, param.fs_kHz, param.sweeps);
            % if we aren't on the diagonal and the masker is focused, then
            % record ABCD frames w masker focused
            else
                % if we have to move the recording electrode because
                % nominally it will overlap with one of the focussing
                % return electrodes
                if abs(param.electrode_masker - param.rec_EL) <= 1
                    % move the recording electrode off the blurred masker
                    if param.electrode_masker - param.rec_EL == 1
                        param.rec_EL = param.rec_EL - 1;                        
                        rec_move = 1;
                    elseif param.electrode_masker - param.rec_EL == -1
                        param.rec_EL = param.rec_EL + 1;
                        rec_move = 1;
                    end
                end
                % correct for if the rec elec is now on the probe                MIGHT HAVE TO REMOVE THIS SECTION
                if param.electrode_probe == param.rec_EL
                    % if the probe is higher than the masker
                    if param.electrode_probe > param.electrode_masker
                        % increase the recording elec by 1
                        param.rec_EL = param.rec_EL + 1;
                        rec_move = 1;
                    % if the probe is lower than the masker
                    elseif param.electrode_probe < param.electrode_masker
                        % decrease the recording elec by 1
                        param.rec_EL = param.rec_EL - 1;
                        rec_move = 1;
                    end                  
                end
                % update adjustment of recording electrode for printing
                stim_struct.ELrec = param.rec_EL;
                % update BEDCS file
                param.exp_file = ...
                    sprintf('ForwardMaskingPTP_M_gain_%d_%dkHz_%d_repeats.bExp',...
                    param.gain, param.fs_kHz, param.sweeps); 
            end

            % create handle to pass to BEDCS
            if param.debug
                handle_BEDCS = [];
            else
                handle_BEDCS = actxserver('BEDCS2.CBEDCSApp');
                handle_BEDCS.Online = 1;
                handle_BEDCS.Visible = 0;


                [current_path, ~, ~] = fileparts(mfilename('fullpath'));
                full_filename = [current_path filesep param.exp_file];

                % Load the file if not already done
                if ~strcmp(handle_BEDCS.ExpFileName, full_filename)
                    handle_BEDCS.LoadExpFile(full_filename)
                end

                % Update the stimulus properties
                fields = fieldnames(stim_struct);
                for i = 1:length(fields)
                    if ~strcmp(fields{i}, 'level')
                        handle_BEDCS.Let_ControlVarVal(fields{i},...
                            stim_struct.(fields{i}))
                    end
                end
                
                % To allow stimulation above 24 uA in BEDCS verson 1.8.321
                % (this is unecessary in version 1.8.337)
                % this turns off the OLS error 
                handle_BEDCS.ULevelMode = 1;
            end

            % print out recording details
            fprintf(['\npTPECAP Recording ' num2str(ii) ' of ' ...
                num2str(length(electrodes)*2-1) '\n']);
            fprintf('\tProbe EL:  %d\t\tProbe Level:  %d\n', ...
                param.electrodes(pidx), MCL_levels(pidx));
            fprintf('\tMasker EL: %d\t\tMasker Level: %d\n', ...
                param.electrodes(midx), MCL_levels(midx));
            fprintf('\tRecording EL: %d\n', param.rec_EL);

            % run BEDCS and collect ECAP (ABCD each time because of
            % variation in stimulus artefact types)
            tic
            signal_all = run_BEDCS_and_get_ECAP(handle_BEDCS,param);
            toc

            % store signal and details in another structure
            PECAP_Data(ii).Probe = stim_struct.ELprobe;
            PECAP_Data(ii).Probe_lvl = stim_struct.level(2);
            PECAP_Data(ii).Masker = stim_struct.ELmasker;
            PECAP_Data(ii).Masker_lvl = stim_struct.level(1);
            PECAP_Data(ii).Recording = stim_struct.ELrec;
            PECAP_Data(ii).PDus = stim_struct.Tp;
            PECAP_Data(ii).MPIus = stim_struct.Tdel;
            if isfield(signal_all,'ECAP')
                PECAP_Data(ii).ECAP = signal_all.ECAP;
            end
            PECAP_Data(ii).frames = signal_all;

            % iterate ii because I'm lazy
            ii = ii + 1;
        end
    end
end

%% Use A and D frames from diagonal to interpolate ECAPs for non-diagonal

for ii = 1:length(PECAP_Data)
    % if the A and D frames don't already exist
    if ~isfield(PECAP_Data(ii).frames,'A')
        for jj = 1:length(PECAP_Data)
            % find the right A and D frames
            if PECAP_Data(jj).Probe == param.pTP_elec && ...
                    PECAP_Data(jj).Masker == param.pTP_elec
                % extract the diagonal recording's A and D frames
                A = PECAP_Data(jj).frames.A;
                D = PECAP_Data(jj).frames.D;
                % add a note for which recorded frame we're coppying from
                PECAP_Data(ii).frames.ADframesTrace = jj;
            end
        end
        % copy A and D frames from diagonal
        PECAP_Data(ii).frames.A = A;
        PECAP_Data(ii).frames.D = D;
        % use diagonal A and C frames to calculate ECAP for current ECAP
        PECAP_Data(ii).ECAP = A - (PECAP_Data(ii).frames.B - ...
            PECAP_Data(ii).frames.C) - D;
    end
    % if the ECAP field isn't there but it's in frames, put it in ECAP
    if isempty(PECAP_Data(ii).ECAP) && isfield(PECAP_Data(ii).frames,'ECAP')
        PECAP_Data(ii).ECAP = PECAP_Data(ii).frames.ECAP;
    end
end

%% print out elapsed time
finish = clock;
diff = finish - start;
if round(diff(6)) > 0
    fprintf('\nPECAP Total Elapsed Time: %d hours %d minutes %d seconds\n', ...
        diff(4), diff(5), round(diff(6)));
else
    fprintf('\nPECAP Total Elapsed Time: %d hours %d minutes %d seconds\n', ...
        diff(4), diff(5)-1, 60 + round(diff(6)));
end